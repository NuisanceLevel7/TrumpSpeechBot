#!/usr/bin/python

import urllib
from BeautifulSoup import *

#url = raw_input('Enter - ')
url = 'file:///home/vengle/projects/TrumpSpeechBot/Speeches/raw/president-trump-speaks-cia-headquarters'

html = urllib.urlopen(url).read()
soup = BeautifulSoup(html)
# Retrieve all of the anchor tags
tags = soup('p')
texts = soup.findAll(text=True)

def visible(element):
    if element.parent.name in ['style', 'script', '[document]', 'head', 'title']:
        return False
    elif re.match('<!--.*-->', str(element)):
        return False
    return True

visible_texts = filter(visible, texts)

for tag in visible_texts:
    print tag

